import java.util.Objects;

public class Bebida extends ItemCardapio{
private String nomeBebida;
private String precoBebida;
private String descricaoBebida;

    // Construtor vazio

    public Bebida() {
    }

    public Bebida(String s, int i, String refrigeranteDeCola) {
    }

    // Construtor completo

    public Bebida(String descricao, String nome, double preco, String nomeBebida, String precoBebida, String descricaoBebida) {
        super(descricao, nome, preco);
        this.nomeBebida = nomeBebida;
        this.precoBebida = precoBebida;
        this.descricaoBebida = descricaoBebida;
    }

    // Get e Set

    public String getNomeBebida() {
        return nomeBebida;
    }

    public void setNomeBebida(String nomeBebida) {
        this.nomeBebida = nomeBebida;
    }

    public String getPrecoBebida() {
        return precoBebida;
    }

    public void setPrecoBebida(String precoBebida) {
        this.precoBebida = precoBebida;
    }

    public String getDescricaoBebida() {
        return descricaoBebida;
    }

    public void setDescricaoBebida(String descricaoBebida) {
        this.descricaoBebida = descricaoBebida;
    }
    // Equals and HashCode

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Bebida bebida = (Bebida) o;
        return Objects.equals(nomeBebida, bebida.nomeBebida) && Objects.equals(precoBebida, bebida.precoBebida) && Objects.equals(descricaoBebida, bebida.descricaoBebida);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), nomeBebida, precoBebida, descricaoBebida);
    }
    // toString

    @Override
    public String toString() {
        return "Bebida{" +
                "nomeBebida='" + nomeBebida + '\'' +
                ", precoBebida='" + precoBebida + '\'' +
                ", descricaoBebida='" + descricaoBebida + '\'' +
                '}';
    }
}
