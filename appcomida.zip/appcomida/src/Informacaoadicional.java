public class Informacaoadicional {
}
