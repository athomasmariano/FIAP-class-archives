import java.util.Objects;

public class ItemCardapio {

    // Atributos
    private String descricao;
    private String nome;
    private double preco;

    // Méteodos

    public void exibir(){
        System.out.println("O seu item é:"
                + this.nome);

    }

    // Construtor vazio

    public ItemCardapio() {
    }


    // Construtor completo

    public ItemCardapio(String descricao, String nome, double preco) {
        this.descricao = descricao;
        this.nome = nome;
        this.preco = preco;
    }

    // Get e Set

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    // Equals and HashCode

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ItemCardapio that = (ItemCardapio) o;
        return Double.compare(preco, that.preco) == 0 && Objects.equals(descricao, that.descricao) && Objects.equals(nome, that.nome);
    }

    @Override
    public int hashCode() {
        return Objects.hash(descricao, nome, preco);
    }

    // toString


    @Override
    public String toString() {
        return "ItemCardapio{" +
                "descricao='" + descricao + '\'' +
                ", nome='" + nome + '\'' +
                ", preco=" + preco +
                '}';
    }

    public String exibirInfo(){
        return toString();
    }
}


