import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        var pratoP1 = new Pratoprincipal("Hambúrger", 20, "Pão com carne, queijo e salada dentro");
        var bebida1 = new Bebida("Coca-Cola", 6, "Refrigerante de cola");
        var pedido1 = new Pedido("Items: " +
                new ArrayList<>());

        pedido1.adicionarItem(pratoP1);
        pedido1.adicionarItem(bebida1);

        pedido1.exibirInfo();
        System.out.println(pedido1);
    }
}



