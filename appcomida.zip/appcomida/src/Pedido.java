import java.util.ArrayList;
import java.util.Objects;
import java.util.List;

public class Pedido extends ItemCardapio {
    // Atributos

    private int idpedido;
    private int idcliente;
    private String status;
    private List<ItemCardapio>  ItensCardapio = new ArrayList<>();

    // Méteodos

    public void adicionarItem(ItemCardapio item){
        ItensCardapio.add(item);
    }
    public void removerItem(ItemCardapio item){
        ItensCardapio.remove(item);
    }
    public void reproduzir(){
        System.out.println("Seu pedido é: " + this.idpedido);
        for(var item:ItensCardapio) {
            item.exibirInfo();
            System.out.println("--------------------");
        }
    }


    // Construtor vazio

    public Pedido(String s) {
    }

    // Construtor completo

    public Pedido(String descricao, String nome, double preco, int idpedido, int idcliente, String status, List<ItemCardapio> itensCardapio) {
        super(descricao, nome, preco);
        this.idpedido = idpedido;
        this.idcliente = idcliente;
        this.status = status;
        ItensCardapio = itensCardapio;
    }

    // Get e Set

    public int getIdpedido() {
        return idpedido;
    }

    public void setIdpedido(int idpedido) {
        this.idpedido = idpedido;
    }

    public int getIdcliente() {
        return idcliente;
    }

    public void setIdcliente(int idcliente) {
        this.idcliente = idcliente;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public List<ItemCardapio> getItensCardapio() {
        return ItensCardapio;
    }

    public void setItensCardapio(List<ItemCardapio> itensCardapio) {
        ItensCardapio = itensCardapio;
    }

    // Equals and HashCode

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Pedido pedido = (Pedido) o;
        return idpedido == pedido.idpedido && idcliente == pedido.idcliente && Objects.equals(status, pedido.status) && Objects.equals(ItensCardapio, pedido.ItensCardapio);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), idpedido, idcliente, status, ItensCardapio);
    }

    // toString

    @Override
    public String toString() {
        return "Pedido{" +
                "idpedido=" + idpedido +
                ", idcliente=" + idcliente +
                ", status='" + status + '\'' +
                ", ItensCardapio=" + ItensCardapio +
                '}';
    }
}


