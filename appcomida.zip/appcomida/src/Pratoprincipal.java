import java.util.Objects;

public class Pratoprincipal extends ItemCardapio{
    private String nomePratoP;
    private double precoPratoP;
    private String descricaoPratoP;

    // Construtor vazio

    public Pratoprincipal() {
    }

    public Pratoprincipal(String hambúrger, int i, String s) {
    }


    // Construtor completo

    public Pratoprincipal(String descricao, String nome, double preco, String nomePratoP, double precoPratoP, String descricaoPratoP) {
        super(descricao, nome, preco);
        this.nomePratoP = nomePratoP;
        this.precoPratoP = precoPratoP;
        this.descricaoPratoP = descricaoPratoP;
    }

    //Equal and HashCode

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Pratoprincipal that = (Pratoprincipal) o;
        return Double.compare(precoPratoP, that.precoPratoP) == 0 && Objects.equals(nomePratoP, that.nomePratoP) && Objects.equals(descricaoPratoP, that.descricaoPratoP);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), nomePratoP, precoPratoP, descricaoPratoP);
    }

    //toString

    @Override
    public String toString() {
        return "Pratoprincipal{" +
                "nomePratoP='" + nomePratoP + '\'' +
                ", precoPratoP=" + precoPratoP +
                ", descricaoPratoP='" + descricaoPratoP + '\'' +
                '}';
    }
}




