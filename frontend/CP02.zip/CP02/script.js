   function validar(){

    //Validação se os campos obrigatórios estão preenchidos
    if(document.getElementById("txtNome").value == ""){
        alert('Por favor, preencha todos os campos');
        document.getElementById("txtNome").focus();
    }
    else if(document.getElementById("txtRg").value == ""){
        alert('Por favor, preencha todos os campos')
        document.getElementById("txtRg").focus();
    }
    else if(document.getElementById("txtCPF").value == ""){
        alert('Por favor, preencha todos os campos')
        document.getElementById("txtCPF").focus();
    }
    else if(document.getElementById("dtNasc").value == ""){
        alert('Por favor, preencha todos os campos')
        document.getElementById("dtNasc").focus();
    }
    else if(document.getElementById("txtSenha").value == ""){
        alert('Por favor, preencha todos os campos')
        document.getElementById("txtSenha").focus();
    }
    else if(document.getElementById("txtConfSenha").value == ""){
        alert('Por favor, preencha todos os campos')
        document.getElementById("txtConfSenha").focus();
    }
 


   }
 