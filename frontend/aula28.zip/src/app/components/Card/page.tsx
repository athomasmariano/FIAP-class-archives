
function Card(){
    return(
    <>
    <h1>Componente Card</h1>
    </>
    )
}
export default Card;
    
export function Auxiliar(){
    return(
        <>
            <h2>Criando funções auxiliares</h2>
        </> 
            
    )
}