
const Meucomponente = () => {
return(
    <>
        { /* Criando Arrow Function */ }
        <h1>Meu componente, criado com a Arrow Function</h1>

    </>

        )
    }
    export default Meucomponente;