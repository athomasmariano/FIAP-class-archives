import Card, { Auxiliar } from "./components/Card/page";
import Header from "./components/Header/Header";
import Meucomponente from "./components/Meucomponente/page";

export default function Home() {
  return (
    <>
      <h1>Hello World!</h1>

      <Card />

      <Meucomponente/>

      <Auxiliar/>
    </>
  )
}