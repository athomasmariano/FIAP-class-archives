'use client'
import { useState } from "react";

export default function Home() {

  const [valor, setValor] = useState(0);

  const [dados, setDados] = useState("");

  const [nome, setNome] = useState("");

  const [conteudo, setConteudo] = useState("");

  const [frase, setFrase] = useState("Lorem ipsum dolor sit amet consectetur adipisicing elit. Distinctio alias quasi maxime ipsum, molestias perspiciatis atque, sequi voluptate sed vero optio voluptatem aperiam, error ut amet adipisci laborum voluptatum voluptates?");
  const [FraseMod, setFraseMod] = useState("");


  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setDados(event.target.value)
  }
  const nomeDigitado = (event: React.ChangeEvent<HTMLInputElement>) => {
    setNome(event.target.value)
  }



  const exibirConteudo = () => {
    setConteudo(nome);
    setNome("")

    const mudaFrase = () => {
      setFraseMod(frase)
      setFrase(FraseMod)
    }

  }

  return (
    <>

      <h1> Trabalhando com userState</h1>



      <h2>Exemplo 01</h2>

      <button onClick={() => { setValor(valor + 1) }} >Incrementar</button>
      <button onClick={() => { setValor(valor - 1) }} disabled={valor == 0}>Decrementar</button>
      <button onClick={() => { setValor(0) }}>Zerar</button>
      <p>Novo Valor: {valor}</p>


      <h2>Exemplo 02</h2>

      Dados <input value={dados} onChange={handleChange} />

      <p>Valor digitado: {dados}</p>



      <h3>Exemplo 03</h3>
      <form onSubmit={(e) => { e.preventDefault() }}>
        Nome: <input value={nome} onChange={nomeDigitado} />
        <button type="button" onClick={exibirConteudo}>Enviar</button>
        <p>Nome digitado:{conteudo}</p>
      </form>


      <h4>Exemplo 4</h4>
      <p></p>
      <button onChange={FraseMod}>Alterar texto</button>

    </>



  );

}
