import java.util.Objects;

public class Bebida extends ItemCardapio {
    private boolean gelada; // Para nós conferirmos se a bebida é gelada ou é quente

    // Metodo
    public void exibirInformacoes() {
        String tipo = gelada ? "Gelada" : "Quente";
        System.out.println("Bebida: " + getNome() + " - " + tipo);
    }

    // Construtor vazio
    public Bebida() {}

    // Construtor completo
    public Bebida(String nome, String descricao, double preco, boolean gelada) {
        super(nome, descricao, preco);
        this.gelada = gelada;
    }

    // Getters e Setters
    public boolean isGelada() {
        return gelada;
    }

    public void setGelada(boolean gelada) {
        this.gelada = gelada;
    }

    // Equals and hashCode
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Bebida)) return false;
        if (!super.equals(o)) return false;
        Bebida bebida = (Bebida) o;
        return gelada == bebida.gelada;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), gelada);
    }

    // toString
    @Override
    public String toString() {
        return "Bebida{" +
                "gelada=" + gelada +
                ", " + super.toString() +
                '}';
    }

}