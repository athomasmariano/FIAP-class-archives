public class Main {
    public static void main(String[] args) {
        PratoPrincipal hamburger = new PratoPrincipal("Hambúrguer", "Hambúrguer com queijo e bacon", 25.50, 15);
        PratoPrincipal batata = new PratoPrincipal("Batata frita", "Batata frita temperada com alecrim", 10.00, 5);
        Bebida refrigerante = new Bebida("Refrigerante", "Refrigerante de cola", 5.00, true);
        Bebida cafe = new Bebida("Café", "Café expresso", 4.00, false);

        // Criando um pedido
        Pedido pedido = new Pedido();
        pedido.adicionarItem(hamburger);
        pedido.adicionarItem(refrigerante);
        pedido.adicionarItem(batata);

        // Exibindo detalhes do pedido
        pedido.exibirDetalhes();

        // Atualizando o status do pedido
        pedido.atualizarStatus("Em preparação");
        pedido.exibirStatus();

        // Removendo um item do pedido
        pedido.removerItem(refrigerante);

        // Adicionando mais um item
        pedido.adicionarItem(cafe);

        // Exibindo os detalhes novamente
        pedido.exibirDetalhes();

        // Atualizando o status para entregue
        pedido.atualizarStatus("Entregue");
        pedido.exibirStatus();
    }
}