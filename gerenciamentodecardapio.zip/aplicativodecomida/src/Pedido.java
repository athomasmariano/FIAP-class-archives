import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

class Pedido {
    private List<ItemCardapio> itens;
    private String status;

    public Pedido() {
        this.itens = new ArrayList<>();
        this.status = "Criado"; // Status inicial
    }

    public void adicionarItem(ItemCardapio item) {
        if (!itens.contains(item)) {
            itens.add(item);
            System.out.println(item.getNome() + " adicionado ao pedido.");
        } else {
            System.out.println(item.getNome() + " já está no pedido.");
        }
    }

    public void removerItem(ItemCardapio item) {
        if (itens.remove(item)) {
            System.out.println(item.getNome() + " removido do pedido.");
        } else {
            System.out.println(item.getNome() + " não encontrado no pedido.");
        }
    }

    public double calcularTotal() {
        double total = 0.0;
        for (ItemCardapio item : itens) {
            total += item.getPreco();
        }
        return total;
    }

    public void atualizarStatus(String novoStatus) {
        this.status = novoStatus;
        System.out.println("Status do pedido atualizado para: " + novoStatus);
    }

    public void exibirDetalhes() {
        System.out.println("Detalhes do Pedido:");
        for (ItemCardapio item : itens) {
            item.exibirInformacoes();
        }
        System.out.println("Total: R$ " + calcularTotal());
        System.out.println("Status do pedido: " + status);
    }

    public void exibirStatus() {
        System.out.println("Status atual do pedido: " + status);
    }
}