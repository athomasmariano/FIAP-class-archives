import java.util.Objects;

public class PratoPrincipal extends ItemCardapio {
    private int tempoPreparo;

    // Metodo
    public void exibirInformacoes() {
        System.out.println("Prato Principal: " + getNome() + " - " + tempoPreparo + " minutos para preparar.");
    }

   // Construtor vazio
    public PratoPrincipal() {}

    // Construtor completo
    public PratoPrincipal(String nome, String descricao, double preco, int tempoPreparo) {
        super(nome, descricao, preco);
        this.tempoPreparo = tempoPreparo;
    }

    // Getters e Setters
    public int getTempoPreparo() {
        return tempoPreparo;
    }

    public void setTempoPreparo(int tempoPreparo) {
        this.tempoPreparo = tempoPreparo;
    }

    //Equals e Hashcode
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        PratoPrincipal that = (PratoPrincipal) o;
        return getTempoPreparo() == that.getTempoPreparo();
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), getTempoPreparo());
    }

    // toString
    @Override
    public String toString() {
        return "PratoPrincipal{" +
                "tempoPreparo=" + tempoPreparo +
                '}';
    }
}
