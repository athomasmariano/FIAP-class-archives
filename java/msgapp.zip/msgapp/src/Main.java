import java.util.List;

public class Main {
    public static void main(String[] args) {
        // Criando os usuários
        Usuario alice = new Usuario("Alice", 1);
        Usuario bob = new Usuario("Bob", 2);

        // Criando o servidor
        Servidor programacao = new Servidor("Programação");

        // Adicionando os usuários no servidor
        programacao.adicionarUsuario(alice);
        programacao.adicionarUsuario(bob);

        // Alice e Bob conversando
        programacao.enviarMensagem(new Mensagem("Bom dia, rapaziada!", alice));
        programacao.enviarMensagem(new Mensagem("Bom dia Alice", bob));
        programacao.enviarMensagem(new Mensagem("Vamos programar!", alice));

        // Listando mensagens no servidor
        System.out.println("Mensagens no servidor 'Programação':");
        programacao.listarMensagens();

        // Listando usuários no servidor
        System.out.println("\nUsuários no servidor 'Programação':");
        programacao.listarUsuarios();

        // Stream API - Estatísticas
        System.out.println("\nTotal de mensagens: " + programacao.contarTotalMensagens());
        System.out.println("Usuário que mais enviou mensagens: " + programacao.encontrarMaiorRemetente());

        // Filtro de mensagens por palavraS chaves
        List<Mensagem> mensagensComOla = programacao.filtrarMensagensPorPalavraChave("Bom dia");
        System.out.println("\nMensagens contendo 'Bom dia':");
        mensagensComOla.forEach(System.out::println);
    }
}

