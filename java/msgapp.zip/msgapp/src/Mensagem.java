import java.time.LocalDateTime;

public class Mensagem {
    private String conteudo;
    private Usuario autor;
    private LocalDateTime dataEnvio;

    public Mensagem(String conteudo, Usuario autor) {
        this.conteudo = conteudo;
        this.autor = autor;
        this.dataEnvio = LocalDateTime.now();
    }

    // Métodos

    public String getConteudo() {
        return conteudo;
    }

    public Usuario getAutor() {
        return autor;
    }

    public LocalDateTime getDataEnvio() {
        return dataEnvio;
    }

    @Override
    public String toString() {
        return "[" + dataEnvio + "] " + autor.getNome() + ": " + conteudo;
    }
}
