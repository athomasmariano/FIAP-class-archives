import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.Comparator;
import java.util.Map;
import java.util.stream.Collectors;

public class Servidor {
    private String nome;
    private List<Usuario> usuarios;
    private List<Mensagem> mensagens;

    public Servidor(String nome) {
        this.nome = nome;
        this.usuarios = new ArrayList<>();
        this.mensagens = new ArrayList<>();
    }

    // Métodos
    public String getNome() {
        return nome;
    }

    public List<Usuario> getUsuarios() {
        return usuarios;
    }

    public List<Mensagem> getMensagens() {
        return mensagens;
    }

    public void adicionarUsuario(Usuario usuario) {
        if (!usuarios.contains(usuario)) {
            usuarios.add(usuario);
        }
    }

    public void removerUsuario(Usuario usuario) {
        usuarios.remove(usuario);
    }

    public void enviarMensagem(Mensagem mensagem) {
        mensagens.add(mensagem);
    }

    public void listarMensagens() {
        for (Mensagem mensagem : mensagens) {
            System.out.println(mensagem);
        }
    }

    public void listarUsuarios() {
        for (Usuario usuario : usuarios) {
            System.out.println(usuario);
        }
    }

    public List<Mensagem> filtrarMensagensPorAutor(Usuario autor) {
        return mensagens.stream()
                .filter(m -> m.getAutor().equals(autor))
                .collect(Collectors.toList());
    }

    public List<Mensagem> filtrarMensagensPorPalavraChave(String palavra) {
        return mensagens.stream()
                .filter(m -> m.getConteudo().toLowerCase().contains(palavra.toLowerCase()))
                .collect(Collectors.toList());
    }

    public long contarTotalMensagens() {
        return mensagens.size();
    }

    public Usuario encontrarMaiorRemetente() {
        return mensagens.stream()
                .collect(Collectors.groupingBy(Mensagem::getAutor, Collectors.counting()))
                .entrySet()
                .stream()
                .max(Map.Entry.comparingByValue())
                .get()
                .getKey();
    }

    public Map<Usuario, Long> agruparMensagensPorUsuario() {
        return mensagens.stream()
                .collect(Collectors.groupingBy(Mensagem::getAutor, Collectors.counting()));
    }
}
