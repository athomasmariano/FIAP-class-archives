import java.util.ArrayList;
import java.util.List;

public class Usuario {
    private String nome;
    private int id;
    private List<Servidor> servidores;

    public Usuario(String nome, int id) {
        this.nome = nome;
        this.id = id;
        this.servidores = new ArrayList<>();
    }

    // Metódos

    public String getNome() {
        return nome;
    }

    public int getId() {
        return id;
    }

    public List<Servidor> getServidores() {
        return servidores;
    }

    public void adicionarServidor(Servidor servidor) {
        if (!servidores.contains(servidor)) {
            servidores.add(servidor);
            servidor.adicionarUsuario(this);
        }
    }

    @Override
    public String toString() {
        return nome + " (ID: " + id + ")";
    }
}