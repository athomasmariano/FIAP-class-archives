public class Avaliacao {
    private Cliente cliente;
    private int nota;
    private String comentario;

    public Avaliacao(Cliente cliente, int nota, String comentario) {
        this.cliente = cliente;
        this.nota = nota;
        this.comentario = comentario;
    }

    public int getNota() {
        return nota;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public String getComentario() {
        return comentario;
    }

    @Override
    public String toString() {
        return String.format("Cliente: %s - Nota: %d - Comentário: %s",
                cliente.getNome(), nota, comentario);
    }
}