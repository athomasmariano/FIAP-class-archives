public class Main {
    public static void main(String[] args) {
        // Criação de clientes
        Cliente cliente1 = new Cliente("Ana");
        Cliente cliente2 = new Cliente("João");
        Cliente cliente3 = new Cliente("Maria");

        // Criação de produtos
        Produto produto1 = new Produto("Smartphone XYZ", 1500.00);
        Produto produto2 = new Produto("Fone de Ouvido ABC", 200.00);

        // Adicionando avaliações aos produtos
        produto1.adicionarAvaliacao(new Avaliacao(cliente1, 5, "Ótimo smartphone!"));
        produto1.adicionarAvaliacao(new Avaliacao(cliente2, 4, "Bom, mas a câmera poderia ser melhor."));
        produto1.adicionarAvaliacao(new Avaliacao(cliente3, 3, "Esperava mais pelo preço."));

        produto2.adicionarAvaliacao(new Avaliacao(cliente1, 4, "Bom fone, qualidade de som excelente."));
        produto2.adicionarAvaliacao(new Avaliacao(cliente2, 2, "Desconfortável após longas horas de uso."));
        produto2.adicionarAvaliacao(new Avaliacao(cliente3, 3, "Custo-benefício razoável."));

        // Exibindo informações dos produtos
        System.out.println(produto1);
        System.out.println(produto2);

        // Listando avaliações com nota maior que 3 para o produto1
        System.out.println("\nAvaliações com nota maior que 3 (Produto 1):");
        produto1.listarAvaliacoesComNotaMaiorQue(3).forEach(System.out::println);

        // Listando avaliações ordenadas por nota do produto2
        System.out.println("\nAvaliações ordenadas por nota (Produto 2):");
        produto2.listarAvaliacoesOrdenadasPorNota().forEach(System.out::println);
    }
}