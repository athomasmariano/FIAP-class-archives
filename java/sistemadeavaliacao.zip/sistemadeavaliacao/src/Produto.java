import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class Produto {
    private String nome;
    private double preco;
    private List<Avaliacao> avaliacoes;

    public Produto(String nome, double preco) {
        this.nome = nome;
        this.preco = preco;
        this.avaliacoes = new ArrayList<>();
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }
    public void adicionarAvaliacao(Avaliacao avaliacao) {
        avaliacoes.add(avaliacao);
    }
    public double calcularMediaAvaliacoes() {
        return avaliacoes.stream()           // Cria uma stream da lista de avaliações
                .mapToInt(Avaliacao::getNota)  // Converte cada avaliação em sua nota
                .average()          // Calcula a média das notas
                .orElse(0.0);       // Se não houver notas, retorna 0
    }
    public List<Avaliacao> listarAvaliacoesComNotaMaiorQue(int notaMinima) {
        return avaliacoes.stream()                       // Cria uma stream da lista de avaliações
                .filter(avaliacao -> avaliacao.getNota() > notaMinima)  // Filtra as avaliações
                .collect(Collectors.toList());  // Coleta as avaliações em uma nova lista
    }
    public List<Avaliacao> listarAvaliacoesOrdenadasPorNota() {
        return avaliacoes.stream()                       // Cria uma stream da lista de avaliações
                .sorted(Comparator.comparingInt(Avaliacao::getNota).reversed())  // Ordena as avaliações pela nota em ordem decrescente
                .collect(Collectors.toList());  // Coleta as avaliações em uma nova lista
    }
    @Override
    public String toString() {
        return "Produto: " + nome + " | Preço: R$" + preco + " | Média de Avaliações: " + calcularMediaAvaliacoes();
    }
}
