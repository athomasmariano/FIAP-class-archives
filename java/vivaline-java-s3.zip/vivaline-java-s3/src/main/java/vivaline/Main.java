package vivaline;

import vivaline.entities.Atendimento;
import vivaline.repositories.AtendimentoRepository;

import java.util.Scanner;

public class Main {
    private static final AtendimentoRepository atendimentoRepository = new AtendimentoRepository();
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            mostrarMenu();
            int opcao = scanner.nextInt();
            scanner.nextLine();  // Consumir a quebra de linha após o número

            switch (opcao) {
                case 1:
                    adicionarAtendimento();
                    break;
                case 2:
                    listarAtendimentos();
                    break;
                case 3:
                    atualizarAtendimento();
                    break;
                case 4:
                    removerAtendimento();
                    break;
                case 0:
                    System.out.println("Saindo...");
                    return; // Encerra o programa
                default:
                    System.out.println("Opção inválida! Tente novamente.");
            }
        }
    }

    // Exibe o menu de opções
    private static void mostrarMenu() {
        System.out.println("\n=== Menu de Atendimentos ===");
        System.out.println("1. Adicionar Atendimento");
        System.out.println("2. Listar Atendimentos");
        System.out.println("3. Atualizar Atendimento");
        System.out.println("4. Remover Atendimento");
        System.out.println("0. Sair");
        System.out.print("Escolha uma opção: ");
    }

    // Adiciona um novo atendimento
    private static void adicionarAtendimento() {
        System.out.println("\n=== Adicionar Atendimento ===");
        System.out.print("Digite o tipo de atendimento: ");
        String tipoAtendimento = scanner.nextLine();
        System.out.print("Digite a descrição: ");
        String descricao = scanner.nextLine();
        System.out.print("Digite a data (dd/MM/yyyy): ");
        String dataString = scanner.nextLine();

        // Para simplificação, estou convertendo a data manualmente para o formato Date
        try {
            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("dd/MM/yyyy");
            java.util.Date data = sdf.parse(dataString);

            Atendimento atendimento = new Atendimento();
            atendimento.setDescricao(descricao);
            atendimento.setData(data);

            atendimentoRepository.adicionar(atendimento);
        } catch (Exception e) {
            System.err.println("Erro ao adicionar atendimento: " + e.getMessage());
        }
    }

    // Lista todos os atendimentos
    private static void listarAtendimentos() {
        System.out.println("\n=== Listar Atendimentos ===");
        atendimentoRepository.listarTodos().forEach(a -> {
            System.out.println("ID: " + a.getId() + " | Descrição: " + a.getDescricao() + " | Data: " + a.getData());
        });
    }

    // Atualiza um atendimento existente
    private static void atualizarAtendimento() {
        System.out.println("\n=== Atualizar Atendimento ===");
        System.out.print("Digite o ID do atendimento a ser atualizado: ");
        int id = scanner.nextInt();
        scanner.nextLine();  // Consumir a quebra de linha após o número
        System.out.print("Digite o novo tipo de atendimento: ");
        String tipoAtendimento = scanner.nextLine();
        System.out.print("Digite a nova descrição: ");
        String descricao = scanner.nextLine();
        System.out.print("Digite a nova data (dd/MM/yyyy): ");
        String dataString = scanner.nextLine();

        // Para simplificação, estou convertendo a data manualmente para o formato Date
        try {
            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("dd/MM/yyyy");
            java.util.Date data = sdf.parse(dataString);

            Atendimento atendimentoAtualizado = new Atendimento();
            atendimentoAtualizado.setDescricao(descricao);
            atendimentoAtualizado.setData(data);

            atendimentoRepository.atualizar(id, atendimentoAtualizado);
        } catch (Exception e) {
            System.err.println("Erro ao atualizar atendimento: " + e.getMessage());
        }
    }

    // Remove um atendimento existente
    private static void removerAtendimento() {
        System.out.println("\n=== Remover Atendimento ===");
        System.out.print("Digite o ID do atendimento a ser removido: ");
        int id = scanner.nextInt();
        scanner.nextLine();  // Consumir a quebra de linha após o número
        atendimentoRepository.remover(id);
    }
}
