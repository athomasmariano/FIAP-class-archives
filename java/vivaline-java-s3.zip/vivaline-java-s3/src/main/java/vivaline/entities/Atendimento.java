package vivaline.entities;

import lombok.*;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Atendimento extends _BaseEntity {
    private String descricao;
    private Date data;

    }
