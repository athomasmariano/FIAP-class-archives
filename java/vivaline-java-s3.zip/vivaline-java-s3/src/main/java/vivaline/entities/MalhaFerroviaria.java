package vivaline.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MalhaFerroviaria {
    private List<String> linhas;
    private List<String> estacoes;

    public void mostrarMapa() {
        System.out.println("Exibindo mapa da malha ferroviária:");
        for (String linha : linhas) {
            System.out.println("Linha: " + linha);
        }
        for (String estacao : estacoes) {
            System.out.println("Estação: " + estacao);
        }
    }
}
