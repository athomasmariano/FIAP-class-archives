package vivaline.entities;

import lombok.*;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Noticia extends _BaseEntity {
    private String titulo;
    private String conteudo;
    private LocalDate dataPublicacao;
}
