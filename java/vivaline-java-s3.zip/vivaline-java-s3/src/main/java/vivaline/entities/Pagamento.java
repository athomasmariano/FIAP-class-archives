package vivaline.entities;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Pagamento extends _BaseEntity {
    private double valor;
    private String metodo;

    public void realizarPagamento() {
        System.out.println("Pagamento de " + valor + " realizado com o método: " + metodo);
    }
}
