package vivaline.entities;

import lombok.*;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Totem extends _BaseEntity {
    private String localizacao;
    private MalhaFerroviaria mapa;
    private List<Noticia> noticias;
    private Atendimento atendimento;

    public void exibirInformacoes() {
        System.out.println("Localização do Totem: " + localizacao);
        System.out.println(mapa);
    }
}
