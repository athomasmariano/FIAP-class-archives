package vivaline.entities;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class Usuario extends _BaseEntity {
    private String nome;
    private String cpf;
    private int idade;
    private String genero;
    private String email;
}
