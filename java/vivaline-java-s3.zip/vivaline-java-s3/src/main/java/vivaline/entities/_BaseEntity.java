package vivaline.entities;

import lombok.*;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public abstract class _BaseEntity {
    private int id; // ID único da entidade
    private boolean ativo = true; // Define se a entidade está ativa
    private LocalDateTime dataCriacao = LocalDateTime.now(); // Registra a data de criação
    private LocalDateTime dataAtualizacao = LocalDateTime.now(); // Registra a última atualização
}
