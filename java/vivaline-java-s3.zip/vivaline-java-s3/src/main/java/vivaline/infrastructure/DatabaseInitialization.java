package vivaline.infrastructure;

import java.sql.Connection;
import java.sql.Statement;

public class DatabaseInitialization {

    public static void initialize() {
        // SQL para criar a tabela "atendimentos"
        String createTableSQL =
                "CREATE TABLE atendimentos (" +
                        "id NUMBER(12) PRIMARY KEY," +
                        "name VARCHAR2(255) NOT NULL," +
                        "email VARCHAR2(255) NOT NULL UNIQUE" +
                        ")";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement()) {

            // Criar a tabela
            stmt.execute(createTableSQL);
            System.out.println("Tabela 'users' criada com sucesso!");

        } catch (Exception e) {
            System.out.println("Erro ao criar a tabela: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        initialize();
    }
}