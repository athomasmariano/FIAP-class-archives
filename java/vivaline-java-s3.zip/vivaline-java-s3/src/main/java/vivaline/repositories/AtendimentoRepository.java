package vivaline.repositories;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import vivaline.entities.Atendimento;
import vivaline.infrastructure.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class AtendimentoRepository implements CrudRepository<Atendimento> {
    private static final Logger logger = LogManager.getLogger(AtendimentoRepository.class);

    @Override
    public void adicionar(Atendimento atendimento) {
        var query = "INSERT INTO ATENDIMENTO (ID, DESCRICAO, DATA) VALUES (?, ?, ?)";
        try (var conn = DatabaseConnection.getConnection()) {
            var stmt = conn.prepareStatement(query);
            stmt.setInt(1, atendimento.getId());
            stmt.setString(2, atendimento.getDescricao());
            stmt.setTimestamp(3, new Timestamp(atendimento.getData().getTime()));  // Convertendo Date para Timestamp
            int result = stmt.executeUpdate();
            if (result > 0) {
                logger.info("Atendimento adicionado com sucesso: " + atendimento);
            }
        } catch (SQLException e) {
            logger.error("Erro ao adicionar atendimento", e);
        }
    }

    @Override
    public void atualizar(int id, Atendimento atendimentoAtualizado) {
        var query = "UPDATE ATENDIMENTO SET TIPO_ATENDIMENTO = ?, DESCRICAO = ?, DATA = ? WHERE ID = ?";
        try (var conn = DatabaseConnection.getConnection()) {
            var stmt = conn.prepareStatement(query);
            stmt.setInt(1, atendimentoAtualizado.getId());
            stmt.setString(2, atendimentoAtualizado.getDescricao());
            stmt.setTimestamp(3, new Timestamp(atendimentoAtualizado.getData().getTime()));  // Convertendo Date para Timestamp
            stmt.setInt(4, id);
            int result = stmt.executeUpdate();
            if (result > 0) {
                logger.info("Atendimento atualizado com sucesso: " + atendimentoAtualizado);
            } else {
                logger.warn("Atendimento não encontrado para atualização. ID: " + id);
            }
        } catch (SQLException e) {
            logger.error("Erro ao atualizar atendimento", e);
        }
    }

    @Override
    public void remover(Atendimento atendimento) {
        var query = "DELETE FROM ATENDIMENTO WHERE ID = ?";
        try (var conn = DatabaseConnection.getConnection()) {
            var stmt = conn.prepareStatement(query);
            stmt.setInt(1, atendimento.getId());
            int result = stmt.executeUpdate();
            if (result > 0) {
                logger.info("Atendimento removido com sucesso: " + atendimento);
            } else {
                logger.warn("Atendimento não encontrado para remoção. ID: " + atendimento.getId());
            }
        } catch (SQLException e) {
            logger.error("Erro ao remover atendimento", e);
        }
    }

    @Override
    public void remover(int id) {
        var query = "DELETE FROM ATENDIMENTO WHERE ID = ?";
        try (var conn = DatabaseConnection.getConnection()) {
            var stmt = conn.prepareStatement(query);
            stmt.setInt(1, id);
            int result = stmt.executeUpdate();
            if (result > 0) {
                logger.info("Atendimento removido com sucesso. ID: " + id);
            } else {
                logger.warn("Atendimento não encontrado para remoção. ID: " + id);
            }
        } catch (SQLException e) {
            logger.error("Erro ao remover atendimento", e);
        }
    }

    @Override
    public void delete(Atendimento atendimento) {
        remover(atendimento);
    }

    @Override
    public void deleteById(int id) {
        remover(id);
    }

    @Override
    public List<Atendimento> listarTodos() {
        var query = "SELECT * FROM ATENDIMENTO";
        var atendimentos = new ArrayList<Atendimento>();
        try (var conn = DatabaseConnection.getConnection()) {
            var stmt = conn.prepareStatement(query);
            var result = stmt.executeQuery();
            while (result.next()) {
                var atendimento = new Atendimento();
                atendimento.setId(result.getInt("ID"));
                atendimento.setDescricao(result.getString("DESCRICAO"));
                atendimento.setData(result.getTimestamp("DATA"));  // Usando o campo Timestamp diretamente
                atendimentos.add(atendimento);
            }
        } catch (SQLException e) {
            logger.error("Erro ao listar atendimentos", e);
        }
        return atendimentos;
    }

    @Override
    public List<Atendimento> listar() {
        return listarTodos();
    }

    @Override
    public Optional<Atendimento> buscarPorId(int id) {
        var query = "SELECT * FROM ATENDIMENTO WHERE ID = ?";
        try (var conn = DatabaseConnection.getConnection()) {
            var stmt = conn.prepareStatement(query);
            stmt.setInt(1, id);
            var result = stmt.executeQuery();
            if (result.next()) {
                var atendimento = new Atendimento();
                atendimento.setId(result.getInt("ID"));
                atendimento.setDescricao(result.getString("DESCRICAO"));
                atendimento.setData(result.getTimestamp("DATA"));  // Usando o campo Timestamp diretamente
                return Optional.of(atendimento);
            }
        } catch (SQLException e) {
            logger.error("Erro ao buscar atendimento por ID", e);
        }
        return Optional.empty();
    }
}
