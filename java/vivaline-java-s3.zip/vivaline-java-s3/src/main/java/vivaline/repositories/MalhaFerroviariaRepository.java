package vivaline.repositories;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import vivaline.entities.MalhaFerroviaria;
import vivaline.infrastructure.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class MalhaFerroviariaRepository implements CrudRepository<MalhaFerroviaria> {
    private MalhaFerroviaria malha;

    @Override
    public void adicionar(MalhaFerroviaria object) {
        try {
            this.malha = object;
            System.out.println("Malha ferroviária definida com sucesso.");
        } catch (Exception e) {
            System.out.println("Erro ao definir a malha ferroviária: " + e.getMessage());
        }
    }

    @Override
    public void atualizar(int id, MalhaFerroviaria object) {
        // Como só existe UMA malha, o ID não faz sentido aqui.
        atualizar(object);
    }

    public void atualizar(MalhaFerroviaria object) {
        try {
            if (this.malha != null) {
                this.malha = object;
                System.out.println("Malha ferroviária atualizada.");
            } else {
                System.out.println("Erro: Nenhuma malha ferroviária definida.");
            }
        } catch (Exception e) {
            System.out.println("Erro ao atualizar a malha ferroviária: " + e.getMessage());
        }
    }

    @Override
    public void remover(MalhaFerroviaria object) {
        try {
            if (this.malha != null && this.malha.equals(object)) {
                this.malha = null;
                System.out.println("Malha ferroviária removida.");
            } else {
                System.out.println("Erro: Malha ferroviária não encontrada.");
            }
        } catch (Exception e) {
            System.out.println("Erro ao remover a malha ferroviária: " + e.getMessage());
        }
    }

    @Override
    public void remover(int id) {
        // Como só existe uma malha, remover por ID não faz sentido
        System.out.println("Operação inválida: Apenas uma malha ferroviária pode existir.");
    }

    @Override
    public void delete(MalhaFerroviaria object) {
        remover(object);
    }

    @Override
    public void deleteById(int id) {
        remover(id);
    }

    @Override
    public List<MalhaFerroviaria> listarTodos() {
        return this.malha != null ? List.of(this.malha) : List.of();
    }

    @Override
    public List<MalhaFerroviaria> listar() {
        return listarTodos();
    }

    @Override
    public Optional<MalhaFerroviaria> buscarPorId(int id) {
        // Como só existe uma malha, retorna ela independente do ID
        return Optional.ofNullable(this.malha);
    }
}
