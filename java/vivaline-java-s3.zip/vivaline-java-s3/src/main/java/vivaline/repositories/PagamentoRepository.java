package vivaline.repositories;

import vivaline.entities.Pagamento;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class PagamentoRepository implements CrudRepository<Pagamento> {
    private final List<Pagamento> pagamentos = new ArrayList<>();

    @Override
    public void adicionar(Pagamento pagamento) {
        try {
            pagamentos.add(pagamento);
            System.out.println("Pagamento adicionado com sucesso: " + pagamento);
        } catch (Exception e) {
            System.err.println("Erro ao adicionar pagamento: " + e.getMessage());
        }
    }

    @Override
    public void atualizar(int id, Pagamento pagamento) {
        try {
            Optional<Pagamento> pagamentoExistente = buscarPorId(id);
            if (pagamentoExistente.isPresent()) {
                pagamentos.remove(pagamentoExistente.get());
                pagamentos.add(pagamento);
                System.out.println("Pagamento atualizado com sucesso: " + pagamento);
            } else {
                System.err.println("Pagamento não encontrado para atualização. ID: " + id);
            }
        } catch (Exception e) {
            System.err.println("Erro ao atualizar pagamento: " + e.getMessage());
        }
    }

    @Override
    public void remover(Pagamento pagamento) {
        try {
            if (pagamentos.remove(pagamento)) {
                System.out.println("Pagamento removido com sucesso: " + pagamento);
            } else {
                System.err.println("Pagamento não encontrado na lista.");
            }
        } catch (Exception e) {
            System.err.println("Erro ao remover pagamento: " + e.getMessage());
        }
    }

    @Override
    public void remover(int id) {
        try {
            Optional<Pagamento> pagamento = buscarPorId(id);
            pagamento.ifPresentOrElse(
                    p -> {
                        pagamentos.remove(p);
                        System.out.println("Pagamento removido com sucesso. ID: " + id);
                    },
                    () -> System.err.println("Pagamento não encontrado para remoção. ID: " + id)
            );
        } catch (Exception e) {
            System.err.println("Erro ao remover pagamento: " + e.getMessage());
        }
    }

    @Override
    public void delete(Pagamento pagamento) {
        remover(pagamento);
    }

    @Override
    public void deleteById(int id) {
        remover(id);
    }

    @Override
    public List<Pagamento> listarTodos() {
        try {
            return new ArrayList<>(pagamentos);
        } catch (Exception e) {
            System.err.println("Erro ao listar pagamentos: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    @Override
    public List<Pagamento> listar() {
        return listarTodos();
    }

    @Override
    public Optional<Pagamento> buscarPorId(int id) {
        try {
            return pagamentos.stream().filter(p -> p.getId() == id).findFirst();
        } catch (Exception e) {
            System.err.println("Erro ao buscar pagamento por ID: " + e.getMessage());
            return Optional.empty();
        }
    }
}
