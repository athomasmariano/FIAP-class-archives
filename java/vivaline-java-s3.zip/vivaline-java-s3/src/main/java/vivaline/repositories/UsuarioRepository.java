package vivaline.repositories;

import vivaline.entities.Usuario;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class UsuarioRepository implements CrudRepository<Usuario> {
    private final List<Usuario> usuarios = new ArrayList<>();

    @Override
    public void adicionar(Usuario usuario) {
        try {
            usuarios.add(usuario);
            System.out.println("Usuário adicionado com sucesso: " + usuario);
        }

        catch (Exception e) {
            System.err.println("Erro ao adicionar usuário: " + e.getMessage());
        }
    }

    @Override
    public void atualizar(int id, Usuario usuario) {
        try {
            Optional<Usuario> usuarioExistente = buscarPorId(id);
            if (usuarioExistente.isPresent()) {
                usuarios.remove(usuarioExistente.get());
                usuarios.add(usuario);
                System.out.println("Usuário atualizado com sucesso: " + usuario);
            } else {
                System.err.println("Usuário não encontrado para atualização. ID: " + id);
            }
        }

        catch (Exception e) {
            System.err.println("Erro ao atualizar usuário: " + e.getMessage());
        }
    }

    @Override
    public void remover(Usuario usuario) {
        try {
            if (usuarios.remove(usuario)) {
                System.out.println("Usuário removido com sucesso: " + usuario);
            } else {
                System.err.println("Usuário não encontrado na lista.");
            }
        }

        catch (Exception e) {
            System.err.println("Erro ao remover usuário: " + e.getMessage());
        }
    }

    @Override
    public void remover(int id) {
        try {
            Optional<Usuario> usuario = buscarPorId(id);
            usuario.ifPresentOrElse(
                    u -> {
                        usuarios.remove(u);
                        System.out.println("Usuário removido com sucesso. ID: " + id);
                    },
                    () -> System.err.println("Usuário não encontrado para remoção. ID: " + id)
            );
        }

        catch (Exception e) {
            System.err.println("Erro ao remover usuário: " + e.getMessage());
        }
    }

    @Override
    public void delete(Usuario usuario) {
        remover(usuario);
    }

    @Override
    public void deleteById(int id) {
        remover(id);
    }

    @Override
    public List<Usuario> listarTodos() {
        try {
            return new ArrayList<>(usuarios);
        }

        catch (Exception e) {
            System.err.println("Erro ao listar usuários: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    @Override
    public List<Usuario> listar() {
        return listarTodos();
    }

    @Override
    public Optional<Usuario> buscarPorId(int id) {
        try {
            return usuarios.stream().filter(u -> u.getId() == id).findFirst();
        }

        catch (Exception e) {
            System.err.println("Erro ao buscar usuário por ID: " + e.getMessage());
            return Optional.empty();
        }
    }
}
